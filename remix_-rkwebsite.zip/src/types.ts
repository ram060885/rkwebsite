export interface Message {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: Date;
}

export interface ServiceDetail {
  id: string;
  title: string;
  icon: string; // Lucide icon name
  shortDesc: string;
  longDesc: string;
  useCases: string[];
  techStack: string[];
}

export interface ExperienceItem {
  id: string;
  period: string;
  role: string;
  company: string;
  highlights: string[];
}
