import { ServiceDetail, ExperienceItem } from "./types";

export const SERVICES: ServiceDetail[] = [
  {
    id: "vba",
    title: "VBA & Excel Automation",
    icon: "FileSpreadsheet",
    shortDesc: "Transform massive, slow spreadsheets into lightning-fast, fully automated reporting tools.",
    longDesc: "Excel remains the bedrock of finance, but manual upkeep is highly inefficient. I formulate ultra-optimized VBA macros and Add-ins that sync instantly with backend databases, streamline ledger audits, and handle data compilation in seconds.",
    useCases: [
      "Bank Reconciliation automation saving hours daily",
      "Dynamic dashboard generation with multi-source databases",
      "Automatic ledger export and formatting with full audit trails",
      "Automated mass email dispatch based on financial data"
    ],
    techStack: ["MS Excel VBA", "ADO/DAO", "SQL Server", "Power Query"]
  },
  {
    id: "rpa",
    title: "Power Automate & RPA",
    icon: "Cpu",
    shortDesc: "End-to-end software integration bridging invoices, emails, filesystems, and databases.",
    longDesc: "I build robust digital robots that mimic human actions across systems. From fetching tax portals' data to reading unstructured PDFs and uploading them directly into your billing engine, RPA completely eliminates repetitive data entry.",
    useCases: [
      "No-code / low-code flows mapping Outlook attachments to server directories",
      "Cross-platform scraping of utility portals and vendor statements",
      "Batch invoice indexing and direct file-system migration",
      "Automated daily audit summary emails sent directly to stakeholders"
    ],
    techStack: ["Power Automate", "UiPath", "Python RPA", "Selenium"]
  },
  {
    id: "ai",
    title: "AI Development & Integration",
    icon: "Brain",
    shortDesc: "Deploy cutting-edge AI agents to analyze transactions, read PDF bills via OCR, and predict trends.",
    longDesc: "Enterprise automation has evolved beyond static logic. I integrate modern LLMs, document understanding models (OCR), and machine learning into financial workflows to intelligently categorize expenses, review tax forms, or extract context from unstructured contracts.",
    useCases: [
      "Smart Receipt OCR & expense classification agents",
      "Semantic reconciliation on fuzzy invoice/payment description matches",
      "AI-driven financial trend analysis & variance breakdown",
      "Conversational interfaces for executive financial query exploration"
    ],
    techStack: ["Gemini API", "@google/genai", "Python AI", "OCR Engine Integration", "Text embeddings"]
  },
  {
    id: "erp",
    title: "ERP & SAP Support Systems",
    icon: "Database",
    shortDesc: "Seamless data pipeline orchestration integrating with major platforms.",
    longDesc: "Maximize the utilization of enterprise systems. I build safe script interfaces, journal upload pipelines, and automated synchronization scripts that bridge custom desktop software, web-scrapes, or spreadsheets straight to major ERP interfaces like SAP.",
    useCases: [
      "Automated multi-entity journal entries uploads without manual entry",
      "SAP GUI automation scripts for rapid ledger extracts",
      "Database schema mirroring and live transaction monitoring",
      "Discrepancy alerting systems comparing filesystems to ERP status"
    ],
    techStack: ["SAP Scripting", "Oracle Financials", "Tally API", "SQL Databases"]
  },
  {
    id: "opt",
    title: "Process Optimization",
    icon: "TrendingUp",
    shortDesc: "Redesigning financial close pathways to clear month-end bottlenecks and ensure compliance.",
    longDesc: "Technology works best when paired with sound strategy. Combining my 18+ years in pure corporate finance and accounting management with deep engineering knowledge, I restructure workflows to minimize compliance risks, eliminate lag, and guarantee clean audit readiness.",
    useCases: [
      "Month-end book closing time reduced by 50%+",
      "Audit preparation packets auto-constructed with backup schedules",
      "Internal controls auditing and compliance gap analysis",
      "Standard Operations Procedure (SOP) digital translation"
    ],
    techStack: ["Finance Control Frameworks", "Audit Guidelines", "Workflow Analysis", "SOP Mapping"]
  }
];

export const EXPERIENCE: ExperienceItem[] = [
  {
    id: "exp-1",
    period: "2016 - Present",
    role: "Senior Accounts & Automation Specialist",
    company: "Enterprise Financial Workflows",
    highlights: [
      "Pioneered Excel VBA and RPA pipelines streamlining critical inter-company bank ledger reconciliations across 15+ subsidiaries.",
      "Engineered automated script tools that reduced month-end closing timelines from 8 business days down to just 3.",
      "Developed custom document ingestion systems using intelligent processing, parsing over 5,000 monthly vendor bills with 99.2% accuracy."
    ]
  },
  {
    id: "exp-2",
    period: "2008 - 2016",
    role: "Accounts Operations Manager",
    company: "Global Corporate Finance Division",
    highlights: [
      "Managed general ledgers, trial balances, taxation fillings, and audit protocols with immaculate accuracy.",
      "Designed and deployed custom VBA macro modules for multi-currency consolidations and treasury forecasting.",
      "Instituted internal control checklists that earned 'Highly Satisfactory' marks consistently in external financial audits."
    ]
  }
];

export const QUICK_STATS = [
  { label: "Years in Finance & Accounts", value: "18+", icon: "Briefcase" },
  { label: "Dedicated to Software Automation", value: "10+", icon: "Cpu" },
  { label: "Manual Hours Saved annually", value: "2,500+", icon: "Clock" },
  { label: "SOP & Close Time Improvement", value: "60%", icon: "Zap" }
];

export const SUGGESTED_QUESTIONS = [
  "How can VBA automate bank reconciliations?",
  "What is your approach to ERP and SAP integration?",
  "Can you describe your ideal workflow for month-end close optimization?",
  "What AI tools are best used for smart financial reporting?"
];
