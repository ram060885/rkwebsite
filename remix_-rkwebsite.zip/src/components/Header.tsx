import { motion } from "motion/react";
import { useState } from "react";
import LucideIcon from "./LucideIcon";
import RkLogo from "./RkLogo";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
      setIsOpen(false);
    }
  };

  return (
    <motion.header 
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 left-0 w-full z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo / Branding */}
          <div 
            className="flex items-center cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          >
            <RkLogo size={36} showText={true} />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection("about")}
              className="text-sm font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Overview
            </button>
            <button 
              onClick={() => scrollToSection("services")}
              className="text-sm font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Expertise
            </button>
            <button 
              onClick={() => scrollToSection("experience")}
              className="text-sm font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Timeline
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="px-4 py-2 rounded-lg bg-pink-600 hover:bg-pink-500 text-sm font-semibold text-white transition-all shadow-md hover:shadow-pink-500/10 cursor-pointer"
            >
              Consultation
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-400 hover:text-white p-2 rounded-md focus:outline-none"
            >
              {isOpen ? <LucideIcon name="X" size={24} /> : <LucideIcon name="Menu" size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-slate-900 border-t border-slate-800"
        >
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3 flex flex-col items-start">
            <button 
              onClick={() => scrollToSection("about")}
              className="w-full text-left px-3 py-2 text-base font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-md"
            >
              Overview
            </button>
            <button 
              onClick={() => scrollToSection("services")}
              className="w-full text-left px-3 py-2 text-base font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-md"
            >
              Expertise
            </button>
            <button 
              onClick={() => scrollToSection("experience")}
              className="w-full text-left px-3 py-2 text-base font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-md"
            >
              Timeline
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="w-full text-left px-3 py-2 text-base font-medium text-pink-500 hover:bg-slate-800 rounded-md"
            >
              Book Consultation
            </button>
          </div>
        </motion.div>
      )}
    </motion.header>
  );
}
