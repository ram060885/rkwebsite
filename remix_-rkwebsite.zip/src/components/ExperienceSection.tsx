import { motion } from "motion/react";
import { EXPERIENCE, QUICK_STATS } from "../data";
import LucideIcon from "./LucideIcon";

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-slate-900 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-24">
          {QUICK_STATS.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-slate-800/40 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-6 text-center group transition-all"
            >
              <div className="mx-auto w-12 h-12 rounded-xl bg-pink-500/10 text-pink-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <LucideIcon name={stat.icon} size={24} />
              </div>
              <h3 className="text-3xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
                {stat.value}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-2 font-mono uppercase tracking-wider">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Timeline Title */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            <span className="text-pink-500 font-mono text-sm tracking-widest uppercase font-bold">Proven Track Record</span>
            <h2 className="text-3xl sm:text-4xl font-display font-extrabold text-white mt-2 tracking-tight">
              18+ Years of Dual Mastery
            </h2>
            <p className="text-slate-400 mt-4 leading-relaxed text-sm sm:text-base">
              A balanced professional background spanning general corporate ledgers, taxation, bank auditing, and comprehensive workflow solutions in multi-national sectors. Under her care, manual processes are systematically converted to code-driven automatons.
            </p>
            
            <div className="mt-8 p-6 bg-slate-800/40 rounded-xl border border-slate-800">
              <div className="flex items-center space-x-3 text-white mb-3">
                <div className="p-2 w-8 h-8 rounded-lg bg-pink-600/20 text-pink-500 flex items-center justify-center">
                  <LucideIcon name="Award" size={18} />
                </div>
                <h4 className="font-display font-bold text-sm tracking-tight">Core Competencies</h4>
              </div>
              <div className="flex flex-wrap gap-2">
                {["Double-entry Accounting", "VBA Excel Add-ins", "Reconciliation Automation", "Audit Preparation", "SQL Reporting", "OCR Processing", "Power Automate"].map((skill) => (
                  <span key={skill} className="text-[11px] font-mono bg-slate-900 border border-slate-800 text-slate-400 px-2 py-1 rounded-md">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Vertical Timelline Column */}
          <div className="lg:col-span-7 relative pl-6 border-l border-slate-800 space-y-12">
            {EXPERIENCE.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: 25 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative"
              >
                {/* Timeline Dot */}
                <div className="absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-4 border-slate-900 bg-pink-500" />

                {/* Period Badge */}
                <span className="inline-block text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-pink-500/10 text-pink-400 border border-pink-500/20 mb-2">
                  {item.period}
                </span>

                {/* Titles */}
                <h3 className="text-xl sm:text-2xl font-display font-bold text-white tracking-tight">
                  {item.role}
                </h3>
                <span className="block text-sm text-slate-400 font-medium mb-4">
                  {item.company}
                </span>

                {/* Bullets */}
                <ul className="space-y-3">
                  {item.highlights.map((bullet, idx) => (
                    <li key={idx} className="flex items-start text-xs sm:text-sm text-slate-300">
                      <div className="flex-shrink-0 text-pink-500 mt-1 mr-3 bg-pink-500/10 p-0.5 rounded-full">
                        <LucideIcon name="Check" size={10} />
                      </div>
                      <span className="leading-relaxed">{bullet}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
}
