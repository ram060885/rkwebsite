import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Message } from "../types";
import { SUGGESTED_QUESTIONS } from "../data";
import LucideIcon from "./LucideIcon";

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "initial-1",
      sender: "ai",
      text: "Hello! I am Ram Halder's Gemini AI Assistant. Ask me anything about Excel/VBA reporting, corporate accounts close bottlenecks, custom ERP reconciliations, or RPA tools!",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}-user`,
      sender: "user",
      text,
      timestamp: new Date()
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    // Build chronological messaging history to feed into Gemini for context
    const chatHistory = messages.map(m => ({
      sender: m.sender,
      text: m.text
    }));

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, history: chatHistory }),
      });

      const data = await response.json();
      
      const aiMsg: Message = {
        id: `msg-${Date.now()}-ai`,
        sender: "ai",
        text: data.reply || "Thank you for your inquiry! Ram Halder will analyze this and respond immediately. Let me know if you would like automated systems scheduled.",
        timestamp: new Date()
      };
      
      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error("Error communicating with AI endpoint:", error);
      
      // Dynamic fallback message if server-side key is not yet fully activated
      const aiMsg: Message = {
        id: `msg-${Date.now()}-ai`,
        sender: "ai",
        text: `Thank you for your interest! RK Halder will review your query personally and follow up.

In the meantime, feel free to submit the detailed contact form or click to call him directly at +91 9818714744!`,
        timestamp: new Date()
      };
      setMessages((prev) => [...prev, aiMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage(inputValue);
    }
  };

  return (
    <>
      {/* Floating Label for AI Assistant */}
      {!isOpen && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.3 }}
          onClick={() => setIsOpen(true)}
          className="fixed bottom-8 right-24 z-50 bg-slate-900/95 hover:bg-slate-800/95 border border-slate-800 hover:border-pink-500/50 text-white text-xs font-mono font-bold px-3.5 py-2.5 rounded-full shadow-2xl flex items-center space-x-2 cursor-pointer transition-all backdrop-blur-sm select-none"
        >
          <span className="h-2 w-2 rounded-full bg-pink-500 animate-pulse" />
          <span>Gemini AI Assistant</span>
        </motion.div>
      )}

      {/* Floating Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Toggle AI Assistant Chatbot"
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-pink-600 hover:bg-pink-500 text-white flex items-center justify-center shadow-2xl cursor-pointer hover:shadow-pink-500/20 transition-shadow focus:outline-none focus:ring-2 focus:ring-pink-500"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close-icon"
              initial={{ rotate: -45, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 45, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <LucideIcon name="X" size={24} />
            </motion.div>
          ) : (
            <motion.div
              key="chat-icon"
              initial={{ rotate: 45, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -45, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative"
            >
              <LucideIcon name="MessageSquare" size={24} />
              <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500"></span>
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Floating Chat Container Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="fixed bottom-24 right-6 z-50 w-[350px] sm:w-[380px] h-[550px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Elegant Header with AI branding */}
            <div className="bg-gradient-to-r from-pink-600 to-pink-500 p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="h-9 w-9 bg-slate-950/20 rounded-lg flex items-center justify-center text-white">
                  <LucideIcon name="Brain" size={20} />
                </div>
                <div>
                  <h4 className="font-display font-extrabold text-sm text-white">Gemini AI Assistant</h4>
                  <div className="flex items-center space-x-1.5 ">
                    <span className="block h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[10px] font-mono text-pink-100 uppercase tracking-wide">Representing RK Halder</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-pink-100 hover:text-white p-1 rounded-md hover:bg-white/10 transition-colors"
              >
                <LucideIcon name="X" size={18} />
              </button>
            </div>

            {/* Message Body area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/80">
              {messages.map((msg) => {
                const isUser = msg.sender === "user";
                return (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={msg.id}
                    className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                      isUser 
                        ? "bg-pink-600 text-white rounded-tr-none" 
                        : "bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none"
                    }`}>
                      {!isUser && (
                        <div className="flex items-center space-x-1.5 mb-1 text-[10px] font-mono font-semibold text-pink-400">
                          <LucideIcon name="Brain" size={12} />
                          <span>AI ASSISTANT</span>
                        </div>
                      )}
                      <p className="whitespace-pre-line">{msg.text}</p>
                    </div>
                  </motion.div>
                );
              })}

              {/* Waiting Loading feedback indicator */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-900 border border-slate-800 text-slate-400 rounded-2xl rounded-tl-none px-4 py-3 flex items-center space-x-1.5">
                    <span className="animate-bounce inline-block h-1.5 w-1.5 bg-pink-500 rounded-full" style={{ animationDelay: "0ms" }} />
                    <span className="animate-bounce inline-block h-1.5 w-1.5 bg-pink-500 rounded-full" style={{ animationDelay: "150ms" }} />
                    <span className="animate-bounce inline-block h-1.5 w-1.5 bg-pink-500 rounded-full" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Questions suggestion panel */}
            <div className="bg-slate-900/50 border-t border-slate-800/80 px-4 py-3">
              <span className="block text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2">Suggested Topics</span>
              <div className="flex flex-col space-y-1.5 max-h-[100px] overflow-y-auto pr-1">
                {SUGGESTED_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSendMessage(q)}
                    disabled={isLoading}
                    className="w-full text-left font-sans text-xs bg-slate-950 hover:bg-slate-800 border border-slate-800/60 hover:border-pink-500/30 text-slate-300 hover:text-white px-3 py-1.5 rounded-lg transition-colors cursor-pointer truncate"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form area */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center space-x-2">
              <input
                type="text"
                placeholder="Ask something..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading}
                className="flex-1 bg-slate-950 border border-slate-800 focus:border-pink-500 text-xs sm:text-sm text-white px-3.5 py-2.5 rounded-xl outline-none placeholder-slate-600"
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSendMessage(inputValue)}
                disabled={!inputValue.trim() || isLoading}
                className="p-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 disabled:bg-slate-800 text-white disabled:text-slate-600 transition-colors cursor-pointer flex-shrink-0"
              >
                <LucideIcon name="Send" size={16} />
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
