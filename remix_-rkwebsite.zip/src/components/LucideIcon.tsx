import { 
  FileSpreadsheet, 
  Cpu, 
  Brain, 
  Database, 
  TrendingUp, 
  Briefcase, 
  Clock, 
  Zap, 
  Phone, 
  Mail, 
  Send, 
  MessageSquare, 
  X, 
  ChevronRight, 
  Sparkles, 
  Menu, 
  ArrowRight, 
  Check,
  Award,
  ArrowLeft,
  Copy,
  MailOpen
} from "lucide-react";

interface LucideIconProps {
  name: string;
  className?: string;
  size?: number;
}

export default function LucideIcon({ name, className = "", size = 20 }: LucideIconProps) {
  switch (name) {
    case "FileSpreadsheet":
      return <FileSpreadsheet className={className} size={size} />;
    case "Cpu":
      return <Cpu className={className} size={size} />;
    case "Brain":
      return <Brain className={className} size={size} />;
    case "Database":
      return <Database className={className} size={size} />;
    case "TrendingUp":
      return <TrendingUp className={className} size={size} />;
    case "Briefcase":
      return <Briefcase className={className} size={size} />;
    case "Clock":
      return <Clock className={className} size={size} />;
    case "Zap":
      return <Zap className={className} size={size} />;
    case "Phone":
      return <Phone className={className} size={size} />;
    case "Mail":
      return <Mail className={className} size={size} />;
    case "Send":
      return <Send className={className} size={size} />;
    case "MessageSquare":
      return <MessageSquare className={className} size={size} />;
    case "X":
      return <X className={className} size={size} />;
    case "ChevronRight":
      return <ChevronRight className={className} size={size} />;
    case "Sparkles":
      return <Sparkles className={className} size={size} />;
    case "Menu":
      return <Menu className={className} size={size} />;
    case "ArrowRight":
      return <ArrowRight className={className} size={size} />;
    case "Check":
      return <Check className={className} size={size} />;
    case "Award":
      return <Award className={className} size={size} />;
    case "ArrowLeft":
      return <ArrowLeft className={className} size={size} />;
    case "Copy":
      return <Copy className={className} size={size} />;
    case "MailOpen":
      return <MailOpen className={className} size={size} />;
    default:
      return <Sparkles className={className} size={size} />;
  }
}
