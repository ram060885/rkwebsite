import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import LucideIcon from "./LucideIcon";

export default function ContactSection() {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorText, setErrorText] = useState("");
  const [fallbackActive, setFallbackActive] = useState(false);
  const [copiedFallback, setCopiedFallback] = useState(false);
  const [fallbackPayload, setFallbackPayload] = useState<{
    name: string;
    email: string;
    query_type: string;
    message: string;
  } | null>(null);

  const copyToClipboard = (type: "email" | "phone", value: string) => {
    navigator.clipboard.writeText(value);
    if (type === "email") {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } else {
      setCopiedPhone(true);
      setTimeout(() => setCopiedPhone(false), 2000);
    }
  };

  const copyFallbackText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFallback(true);
    setTimeout(() => setCopiedFallback(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorText("");

    const form = e.currentTarget;
    const data = new FormData(form);
    
    const payload = {
      name: data.get("name"),
      email: data.get("email"),
      query_type: data.get("query_type") || "General Inquiry",
      message: data.get("message"),
      _subject: `New Portfolio Lead from ${data.get("name")} [${data.get("query_type")}]`,
      _captcha: "false"
    };

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (response.ok && result.success) {
        setIsSubmitted(true);
        setFallbackActive(false);
        setFallbackPayload(null);
        form.reset();
      } else if (result.fallback) {
        setFallbackActive(true);
        setFallbackPayload({
          name: String(payload.name || ""),
          email: String(payload.email || ""),
          query_type: String(payload.query_type || "General Inquiry"),
          message: String(payload.message || "")
        });
      } else {
        throw new Error(result.error || result.message || "Failed to send message. Please contact via direct email or mobile.");
      }
    } catch (err: any) {
      console.error("Form transmission error:", err);
      setErrorText(err.message || "An unexpected error occurred. Please try again or call directly.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-20 bg-slate-950 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Contact Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-pink-500 font-mono text-sm tracking-widest uppercase font-bold">Get In Touch</span>
            <h2 className="text-3xl sm:text-4xl font-display font-extrabold text-white mt-2 tracking-tight">
              Start Your Automation Journey
            </h2>
            <p className="text-slate-400 mt-4 text-sm sm:text-base">
              Ready to eliminate repetitive spreadsheet entry or design an intelligent reconciliation tool? Write directly or use the secure form below.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Methods Card */}
          <div className="lg:col-span-4 flex flex-col justify-between space-y-6">
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-2xl flex-1 flex flex-col justify-center"
            >
              <h3 className="text-xl font-display font-bold text-white mb-6">Direct Consultation</h3>
              
              {/* Phone item */}
              <div className="mb-6 group">
                <span className="block text-xs font-mono text-slate-500 uppercase tracking-widest mb-1.5">Direct Call</span>
                <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800/80 group-hover:border-slate-700/50 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className="text-pink-500">
                      <LucideIcon name="Phone" size={18} />
                    </div>
                    <a href="tel:+919818714744" className="text-sm font-semibold text-slate-200 hover:text-pink-500 transition-colors">
                      +91 9818714744
                    </a>
                  </div>
                  <button 
                    onClick={() => copyToClipboard("phone", "+919818714744")}
                    className="text-xs text-slate-500 hover:text-slate-300 font-mono tracking-tight cursor-pointer"
                  >
                    {copiedPhone ? "Copied!" : "Copy"}
                  </button>
                </div>
              </div>

              {/* Email item */}
              <div className="group">
                <span className="block text-xs font-mono text-slate-500 uppercase tracking-widest mb-1.5">Email Inquiry</span>
                <div className="flex items-center justify-between p-3.5 bg-slate-950 rounded-xl border border-slate-800/80 group-hover:border-slate-700/50 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className="text-pink-500">
                      <LucideIcon name="Mail" size={18} />
                    </div>
                    <a href="mailto:rk.10.halder@gmail.com" className="text-sm font-semibold text-slate-200 hover:text-pink-500 transition-colors truncate max-w-[150px] sm:max-w-none">
                      rk.10.halder@gmail.com
                    </a>
                  </div>
                  <button 
                    onClick={() => copyToClipboard("email", "rk.10.halder@gmail.com")}
                    className="text-xs text-slate-500 hover:text-slate-300 font-mono tracking-tight cursor-pointer"
                  >
                    {copiedEmail ? "Copied!" : "Copy"}
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Quick Note widget */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-pink-500/10 border border-pink-500/20 p-5 rounded-2xl flex items-start space-x-4"
            >
              <div className="text-pink-500 p-2.5 bg-pink-500/10 rounded-xl flex-shrink-0">
                <LucideIcon name="Zap" size={18} />
              </div>
              <div>
                <h4 className="font-display font-bold text-sm text-pink-400">Guaranteed Response</h4>
                <p className="text-xs text-slate-300 leading-relaxed mt-1">
                  RK generally reviews and replies to automation requests within 2 business days. Provide details on your software versions (Excel, SAP, ERP) for a speedier evaluation!
                </p>
              </div>
            </motion.div>

          </div>

          {/* Form Card */}
          <div className="lg:col-span-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-2xl h-full shadow-2xl flex flex-col justify-center"
            >
              <AnimatePresence mode="wait">
                {fallbackActive && fallbackPayload ? (
                  <motion.div
                    key="fallback-view"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-4 px-2 space-y-6 flex flex-col items-stretch"
                  >
                    <div className="flex flex-col items-center justify-center space-y-3">
                      <div className="h-12 w-12 bg-pink-500/10 border border-pink-500/20 rounded-xl text-pink-500 flex items-center justify-center shadow-md animate-pulse">
                        <LucideIcon name="MailOpen" size={24} />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-xl font-display font-bold text-white tracking-tight">Direct Mail Dispatcher Active</h4>
                        <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                          The routing server is experiencing temporary connection delays with the FormSubmit origin. We've structured your message safely so you can dispatch it instantly via your preferred mail client!
                        </p>
                      </div>
                    </div>

                    <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 text-left space-y-3">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                        <div className="space-y-0.5">
                          <span className="block text-[9px] font-mono uppercase text-slate-500 tracking-wider">Recipient Address</span>
                          <span className="text-xs font-semibold text-slate-200">rk.10.halder@gmail.com</span>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[9px] bg-pink-500/10 border border-pink-500/20 font-mono text-pink-400">Direct Route</span>
                      </div>

                      <div className="space-y-0.5">
                        <span className="block text-[9px] font-mono uppercase text-slate-500 tracking-wider">Email Subject</span>
                        <span className="text-xs font-semibold text-slate-300">
                          Portfolio Inquiry: {fallbackPayload.query_type} from {fallbackPayload.name}
                        </span>
                      </div>

                      <div className="space-y-1.5 pt-1">
                        <span className="block text-[9px] font-mono uppercase text-slate-500 tracking-wider">Inquiry Body Preview</span>
                        <div className="max-h-28 overflow-y-auto bg-slate-900/60 p-3 rounded-lg border border-slate-800/80 text-[11px] font-mono text-slate-400 leading-relaxed whitespace-pre-wrap">
                          {`Hi Ram,\n\nMy name is ${fallbackPayload.name} (${fallbackPayload.email}).\nInside your automation portfolio, I requested support for: ${fallbackPayload.query_type}.\n\nHere are my inquiry details:\n------------------------------------------\n${fallbackPayload.message}\n------------------------------------------\n\nPlease get back to me. Thank you!`}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      <a
                        href={`mailto:rk.10.halder@gmail.com?subject=${encodeURIComponent(`Portfolio Inquiry: ${fallbackPayload.query_type} from ${fallbackPayload.name}`)}&body=${encodeURIComponent(
                          `Hi Ram,\n\nMy name is ${fallbackPayload.name} (${fallbackPayload.email}).\nInside your automation portfolio, I requested support for: ${fallbackPayload.query_type}.\n\nHere are my inquiry details:\n------------------------------------------\n${fallbackPayload.message}\n------------------------------------------\n\nPlease get back to me. Thank you!`
                        )}`}
                        className="w-full bg-pink-600 hover:bg-pink-500 text-sm font-bold text-white py-3 px-4 rounded-xl shadow-lg shadow-pink-500/10 flex items-center justify-center space-x-2.5 transition-colors cursor-pointer"
                      >
                        <LucideIcon name="MailOpen" size={16} />
                        <span>Open & Dispatch Mail Client</span>
                      </a>

                      <div className="grid grid-cols-2 gap-2.5">
                        <button
                          onClick={() => {
                            const bodyText = `To: rk.10.halder@gmail.com\nSubject: Portfolio Inquiry: ${fallbackPayload.query_type} from ${fallbackPayload.name}\n\nHi Ram,\n\nMy name is ${fallbackPayload.name} (${fallbackPayload.email}).\nI need assistance with ${fallbackPayload.query_type}.\n\nDetails:\n${fallbackPayload.message}`;
                            copyFallbackText(bodyText);
                          }}
                          className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs text-slate-300 transition-colors cursor-pointer flex items-center justify-center space-x-2"
                        >
                          <LucideIcon name={copiedFallback ? "Check" : "Copy"} size={13} />
                          <span>{copiedFallback ? "Copied Raw Body!" : "Copy Raw Body"}</span>
                        </button>

                        <button
                          onClick={() => {
                            setFallbackActive(false);
                            setFallbackPayload(null);
                          }}
                          className="py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-slate-800/60 border border-slate-800/80 font-semibold text-xs text-slate-400 hover:text-slate-200 transition-all cursor-pointer flex items-center justify-center space-x-1"
                        >
                          <LucideIcon name="ArrowLeft" size={13} />
                          <span>Tweak Message</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ) : !isSubmitted ? (
                  <motion.div
                    key="form-view"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <h3 className="text-xl font-display font-bold text-white mb-6">Brief Your Automation Project</h3>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Name field */}
                        <div>
                          <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1.5 tracking-wider">Your Name <span className="text-pink-500">*</span></label>
                          <input 
                            type="text" 
                            name="name" 
                            placeholder="e.g. Ram" 
                            required
                            disabled={isSubmitting}
                            className="w-full bg-slate-950 border border-slate-800 focus:border-pink-500 rounded-xl px-4 py-3 text-sm text-white font-sans outline-none transition-all placeholder-slate-600 disabled:opacity-55"
                          />
                        </div>

                        {/* Email field */}
                        <div>
                          <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1.5 tracking-wider">Your Email <span className="text-pink-500">*</span></label>
                          <input 
                            type="email" 
                            name="email" 
                            placeholder="e.g. name@domain.com" 
                            required
                            disabled={isSubmitting}
                            className="w-full bg-slate-950 border border-slate-800 focus:border-pink-500 rounded-xl px-4 py-3 text-sm text-white font-sans outline-none transition-all placeholder-slate-600 disabled:opacity-55"
                          />
                        </div>
                      </div>

                      {/* Query type dropdown */}
                      <div>
                        <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1.5 tracking-wider">Select Your Query Type <span className="text-pink-500">*</span></label>
                        <select 
                          name="query_type" 
                          required
                          disabled={isSubmitting}
                          className="w-full bg-slate-950 border border-slate-800 focus:border-pink-500 rounded-xl px-4 py-3 text-sm text-white font-sans outline-none transition-all cursor-pointer appearance-none disabled:opacity-55"
                          style={{
                            backgroundImage: `url("data:image/svg+xml;utf8,<svg fill='none' stroke='%23e91e63' stroke-width='2' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'><path stroke-linecap='round' stroke-linejoin='round' d='M19.5 8.25l-7.5 7.5-7.5-7.5'></path></svg>")`,
                            backgroundPosition: "right 16px center",
                            backgroundSize: "16px",
                            backgroundRepeat: "no-repeat"
                          }}
                        >
                          <option value="" className="bg-slate-900 text-slate-400">Select Your Query</option>
                          <option className="bg-slate-900 text-slate-100" value="VBA Automation">VBA Automation</option>
                          <option className="bg-slate-900 text-slate-100" value="AI Development">AI Development</option>
                          <option className="bg-slate-900 text-slate-100" value="Power Automate / RPA">Power Automate / RPA</option>
                          <option className="bg-slate-900 text-slate-100" value="ERP / SAP Support">ERP / SAP Support</option>
                          <option className="bg-slate-900 text-slate-100" value="Finance Process Optimization">Finance Process Optimization</option>
                          <option className="bg-slate-900 text-slate-100" value="Other">Other</option>
                        </select>
                      </div>

                      {/* Message text area */}
                      <div>
                        <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1.5 tracking-wider">Message Details <span className="text-pink-500">*</span></label>
                        <textarea 
                          name="message" 
                          rows={4} 
                          placeholder="Briefly state your spreadsheet, SAP workflow system, or reconciliation hurdle..." 
                          required
                          disabled={isSubmitting}
                          className="w-full bg-slate-950 border border-slate-800 focus:border-pink-500 rounded-xl px-4 py-3 text-sm text-white font-sans outline-none transition-all placeholder-slate-600 resize-none disabled:opacity-55"
                        ></textarea>
                      </div>

                      {/* Error feedback message */}
                      {errorText && (
                        <motion.div 
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="text-xs text-rose-500 font-mono bg-rose-500/10 p-3 rounded-lg border border-rose-500/20"
                        >
                          {errorText}
                        </motion.div>
                      )}

                      {/* Submit button */}
                      <motion.button 
                        whileHover={{ scale: isSubmitting ? 1 : 1.01 }}
                        whileTap={{ scale: isSubmitting ? 1 : 0.99 }}
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-pink-600 hover:bg-pink-500 disabled:bg-slate-800 disabled:text-slate-500 text-sm font-bold text-white py-3.5 px-4 rounded-xl shadow-lg shadow-pink-500/10 focus:outline-none focus:ring-2 focus:ring-pink-500 cursor-pointer flex items-center justify-center space-x-2.5 transition-colors disabled:cursor-not-allowed"
                      >
                        {isSubmitting ? (
                          <>
                            <span className="h-4 w-4 rounded-full border-2 border-slate-400 border-t-pink-500 animate-spin" />
                            <span>Transmitting Lead...</span>
                          </>
                        ) : (
                          <>
                            <span>Send Secure Message</span>
                            <LucideIcon name="Send" size={16} />
                          </>
                        )}
                      </motion.button>
                    </form>
                  </motion.div>
                ) : (
                  <motion.div
                    key="success-view"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center py-10 px-4 space-y-6 flex flex-col items-center justify-center"
                  >
                    <div className="h-16 w-16 bg-pink-500/10 border border-pink-500/20 rounded-2xl text-pink-500 flex items-center justify-center shadow-lg animate-bounce">
                      <LucideIcon name="Check" size={32} />
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="text-2xl font-display font-extrabold text-white tracking-tight">Transmission Success!</h4>
                      <p className="text-sm text-slate-400 max-w-sm ml-auto mr-auto leading-relaxed">
                        Thank you! Your automation blueprint has been securely dispatched to the routing server.
                      </p>
                    </div>

                    <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 max-w-sm text-xs text-slate-400 leading-relaxed font-mono text-left space-y-2">
                      <p className="font-semibold text-pink-400">💡 First-Time Activation Tip:</p>
                      <p>
                        To ensure form messages deliver to <strong className="text-slate-200">rk.10.halder@gmail.com</strong>, check your inbox (including Spam or Promotions folders) for an activation email from <strong>FormSubmit</strong>.
                      </p>
                      <p>
                        Simply <strong>click the activation link once</strong> to authorize deliveries from this domain. Once validated, every customer inquiry will hit your inbox instantly!
                      </p>
                    </div>

                    <button
                      onClick={() => setIsSubmitted(false)}
                      className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-xs text-slate-300 transition-colors cursor-pointer"
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

        </div>

      </div>
    </section>
  );
}

