import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  size: number;
  speed: number;
  opacity: number;
  twinkleDir: number;
  color: string;
}

export default function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let stars: Star[] = [];

    const handleResize = () => {
      // Set to match actual document scroll height so the stars are visible on the entire page
      const width = document.documentElement.scrollWidth || window.innerWidth;
      const height = Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight,
        window.innerHeight
      );
      
      canvas.width = width;
      canvas.height = height;
      initStars(width, height);
    };

    const initStars = (width: number, height: number) => {
      stars = [];
      // Dynamic star count based on area
      const numStars = Math.floor((width * height) / 10000);
      const colors = [
        "rgba(255, 255, 255, ", // Pure white
        "rgba(244, 63, 94, ",   // Rose-500
        "rgba(236, 72, 153, ",  // Pink-500
        "rgba(224, 242, 254, ",  // Light blue secondary twinkle
      ];

      for (let i = 0; i < numStars; i++) {
        const rand = Math.random();
        let colorTemplate = colors[0]; // default white
        
        if (rand > 0.85) {
          colorTemplate = colors[1]; // rose
        } else if (rand > 0.70) {
          colorTemplate = colors[2]; // pink
        } else if (rand > 0.60) {
          colorTemplate = colors[3]; // light blue
        }

        stars.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * 1.6 + 0.4,
          speed: Math.random() * 0.20 + 0.05, // very slow elegant crawling speed
          opacity: Math.random() * 0.7 + 0.3,
          twinkleDir: Math.random() > 0.5 ? 1 : -1,
          color: colorTemplate,
        });
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const star of stars) {
        // Draw star with custom color and individual opacity
        ctx.fillStyle = `${star.color}${star.opacity})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, 2 * Math.PI);
        ctx.fill();

        // Slow movement upwards
        star.y -= star.speed;
        
        // Soft twinkle animation
        star.opacity += star.twinkleDir * 0.006;

        if (star.opacity >= 0.95) {
          star.opacity = 0.95;
          star.twinkleDir = -1;
        } else if (star.opacity <= 0.15) {
          star.opacity = 0.15;
          star.twinkleDir = 1;
        }

        // Reset positions smoothly if star wanders off boundaries
        if (star.y < 0) {
          star.y = canvas.height;
          star.x = Math.random() * canvas.width;
        }
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    // Listen to resize & load events to re-calculate dimensions
    window.addEventListener("resize", handleResize);
    
    // Initial setup with a slight delay to allow layout calculation
    const timer = setTimeout(() => {
      handleResize();
    }, 100);

    animate();

    return () => {
      window.removeEventListener("resize", handleResize);
      clearTimeout(timer);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="background-starfield"
      className="absolute top-0 left-0 w-full min-h-screen pointer-events-none -z-20 bg-transparent block"
      style={{ mixBlendMode: "screen" }}
    />
  );
}
