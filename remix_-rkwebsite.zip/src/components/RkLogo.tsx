import React from "react";

interface RkLogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
  textColor?: string;
  vertical?: boolean;
}

export default function RkLogo({
  className = "",
  size = 48,
  showText = true,
  textColor = "text-white",
  vertical = false,
}: RkLogoProps) {
  return (
    <div className={`flex ${vertical ? "flex-col items-center text-center space-y-3" : "items-center space-x-3"} ${className}`}>
      {/* High Fidelity Scalable SVG Logo Icon */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="flex-shrink-0 select-none transform hover:rotate-6 transition-transform duration-500"
      >
        <g id="rk-logo-gear">
          {/* 12 Outer Gear Teeth with Pink Outlines and Grey Core */}
          {Array.from({ length: 12 }).map((_, i) => (
            <rect
              key={i}
              x="44"
              y="4"
              width="12"
              height="18"
              rx="3"
              fill="#4b5563"
              stroke="#eb0072"
              strokeWidth="2.5"
              strokeLinejoin="round"
              transform={`rotate(${i * 30} 50 50)`}
            />
          ))}

          {/* Core Outer Boundary Ring */}
          <circle
            cx="50"
            cy="50"
            r="38"
            fill="#111827"
            stroke="#eb0072"
            strokeWidth="2.5"
          />

          {/* Deep Navy/Blue Inner Core Chamber */}
          <circle
            cx="50"
            cy="50"
            r="32"
            fill="#0b2240"
            stroke="#1e3a8a"
            strokeWidth="3.5"
          />

          {/* Thin Pink Guider Concentric Circle */}
          <circle
            cx="50"
            cy="50"
            r="26"
            stroke="#eb0072"
            strokeWidth="1"
            strokeDasharray="4 3"
          />

          {/* STYLIZED "RK" UNION PATHS */}
          {/* THE 'R': Left shelf bar + primary stem + loop */}
          {/* Left top extension representing state-of-the-art flow */}
          <path
            d="M 16 35 H 44 C 52 35 52 46 44 46 H 32"
            stroke="#0f3460"
            strokeWidth="5.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M 16 35 H 44 C 52 35 52 46 44 46 H 32"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* 'R' Vertical Primary Stem */}
          <path
            d="M 32 35 V 65"
            stroke="#0f3460"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          <path
            d="M 32 35 V 65"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* 'R' Right-slanting leg */}
          <path
            d="M 37 46 L 46 65"
            stroke="#0f3460"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          <path
            d="M 37 46 L 46 65"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* THE 'K': Stem & lower fork (navy + silver base) */}
          <path
            d="M 52 35 V 65"
            stroke="#0f3460"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          <path
            d="M 52 35 V 65"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          
          <path
            d="M 52 48 L 65 65"
            stroke="#0f3460"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          <path
            d="M 52 48 L 65 65"
            stroke="#e2e8f0"
            strokeWidth="3.5"
            strokeLinecap="round"
          />

          {/* THE 'K' UPWARD ARROW: Symbolizes Growth and Intelligence Expansion */}
          {/* Arrowshaft */}
          <path
            d="M 52 48 L 70 24"
            stroke="#0f3460"
            strokeWidth="7"
            strokeLinecap="square"
          />
          <path
            d="M 52 48 L 70 24"
            stroke="#eb0072"
            strokeWidth="4"
            strokeLinecap="square"
          />

          {/* Arrowhead pointed up-right */}
          <path
            d="M 59 23 L 73 20 L 70 33 Z"
            fill="#eb0072"
            stroke="#0f3460"
            strokeWidth="1.5"
          />
        </g>
      </svg>

      {/* Brand Text Branding with custom Plus Jakarta Sans styling */}
      {showText && (
        <div className="flex flex-col text-left leading-none">
          <span className={`font-display font-extrabold tracking-tight ${textColor} ${size < 40 ? "text-sm" : "text-lg"} whitespace-nowrap`}>
            RK AUTOMATION
          </span>
          <span className="font-pink font-bold text-pink-500 tracking-widest text-[9px] uppercase mt-0.5">
            INTELLIGENT SYSTEMS
          </span>
        </div>
      )}
    </div>
  );
}
