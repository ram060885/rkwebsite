import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { SERVICES } from "../data";
import LucideIcon from "./LucideIcon";

export default function ServicesSection() {
  const [activeTab, setActiveTab] = useState(SERVICES[0].id);
  const currentService = SERVICES.find((s) => s.id === activeTab) || SERVICES[0];

  return (
    <section id="services" className="py-20 bg-slate-900 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-pink-500 font-mono text-sm tracking-widest uppercase font-bold">What I Deliver</span>
            <h2 className="text-3xl sm:text-4xl font-display font-extrabold text-white mt-2 tracking-tight">
              Enterprise Automation & Financial Systems
            </h2>
            <p className="text-slate-400 mt-4 text-base sm:text-lg">
              Empowering corporate finance divisions through elite dual capabilities: 18+ years of core accounting practice coupled with 10+ years dedicated strictly to custom code, RPA, and AI.
            </p>
          </motion.div>
        </div>

        {/* Tab Selection Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Service Tabs */}
          <div className="lg:col-span-4 flex flex-col space-y-2 md:space-y-3">
            {SERVICES.map((service, index) => {
              const isActive = service.id === activeTab;
              return (
                <button
                  key={service.id}
                  onClick={() => setActiveTab(service.id)}
                  className={`relative flex items-center p-4 rounded-xl text-left transition-all ${
                    isActive 
                      ? "bg-slate-800 text-white shadow-lg border border-slate-700/50" 
                      : "bg-slate-900 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200 border border-transparent"
                  } cursor-pointer group`}
                >
                  <div className={`p-2.5 rounded-lg mr-4 transition-colors ${
                    isActive ? "bg-pink-600 text-white" : "bg-slate-800 text-slate-400 group-hover:text-pink-400"
                  }`}>
                    <LucideIcon name={service.icon} size={20} />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm sm:text-base">{service.title}</h3>
                    <p className="text-xs text-slate-400 leading-tight mt-0.5 line-clamp-1">{service.shortDesc}</p>
                  </div>
                  {isActive && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="absolute left-1 top-3 bottom-3 w-1 bg-pink-500 rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Active Service Details Display Panel */}
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-slate-800/50 backdrop-blur-sm p-6 sm:p-8 rounded-2xl border border-slate-700/50 shadow-xl"
              >
                {/* Header info */}
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-4 rounded-xl bg-pink-500/10 text-pink-500">
                    <LucideIcon name={currentService.icon} size={32} />
                  </div>
                  <div>
                    <span className="text-pink-500 font-mono text-xs font-semibold">CAPABILITY PROFILE</span>
                    <h3 className="text-2xl font-display font-extrabold text-white tracking-tight">{currentService.title}</h3>
                  </div>
                </div>

                {/* Description */}
                <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-8">
                  {currentService.longDesc}
                </p>

                {/* Core Use Cases list */}
                <div className="mb-8">
                  <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-4">
                    PROVEN ENTERPRISE DEPLOYMENTS
                  </h4>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {currentService.useCases.map((useCase, idx) => (
                      <motion.li 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        key={idx} 
                        className="flex items-start text-sm text-slate-300 bg-slate-900/40 p-3 rounded-lg border border-slate-800"
                      >
                        <div className="text-pink-500 mr-2 mt-0.5">
                          <LucideIcon name="Check" size={16} />
                        </div>
                        <span>{useCase}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>

                {/* Tech Stack details */}
                <div className="border-t border-slate-700/50 pt-6">
                  <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-3">
                    TOOLBOX & STACK
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {currentService.techStack.map((tech) => (
                      <span 
                        key={tech} 
                        className="text-xs font-mono bg-slate-900 border border-slate-700/60 text-slate-300 px-3 py-1.5 rounded-md hover:border-pink-500/50 hover:text-pink-400 transition-colors"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
