import { motion } from "motion/react";
import LucideIcon from "./LucideIcon";

export default function Hero() {
  const scrollToContact = () => {
    const el = document.getElementById("contact");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToExpertise = () => {
    const el = document.getElementById("services");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="about" className="relative min-h-screen pt-32 pb-20 bg-slate-950 flex items-center overflow-hidden border-b border-slate-900">
      {/* Background visual graphics */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-50">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-20" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Hero text copy */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6 text-left">
            
            {/* Elegant pill badge */}
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="inline-flex items-center space-x-2 bg-pink-500/10 border border-pink-500/20 px-3 py-1.5 rounded-full"
            >
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-pink-500"></span>
              </span>
              <span className="text-xs font-mono font-bold text-pink-400 uppercase tracking-widest">
                Available for Global Consultations
              </span>
            </motion.div>

            {/* Display headline */}
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-display font-extrabold text-white tracking-tight leading-tight"
            >
              Ram Halder
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="border-l-4 border-pink-600 pl-4 py-1"
            >
              <h2 className="text-xl sm:text-2xl font-display font-bold text-pink-500">
                Finance & Accounts Automation Expert
              </h2>
            </motion.div>

            {/* Supporting description */}
            <motion.p 
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="text-slate-400 text-base sm:text-lg leading-relaxed max-w-2xl"
            >
              Pioneering a unique convergence of <strong className="text-white font-semibold">18+ years of financial mastery</strong> and <strong className="text-white font-semibold">10+ years of high-performance automation engineering</strong>. Specializing in Excel VBA Add-ins, corporate reconciliation AI systems, and secure ERP/SAP process integration.
            </motion.p>

            {/* CTA Actions */}
            <motion.div 
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
            >
              <button 
                onClick={scrollToContact}
                className="px-6 py-4 rounded-xl bg-pink-600 hover:bg-pink-500 transition-colors text-white font-bold text-sm tracking-wide shadow-lg shadow-pink-500/10 cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>Automate My Close</span>
                <LucideIcon name="ArrowRight" size={16} />
              </button>
              <button 
                onClick={scrollToExpertise}
                className="px-6 py-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 transition-colors text-slate-300 hover:text-white font-semibold text-sm cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>Explore Capabilities</span>
              </button>
            </motion.div>

          </div>

          {/* Interactive Visual Graphic */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative mx-auto max-w-[340px] sm:max-w-[400px]">
              
              {/* Outer decorative card frame */}
              <div className="absolute inset-0 bg-gradient-to-tr from-pink-500 to-blue-500 rounded-2xl blur opacity-20 -m-1" />
              
              {/* Profile/Value statement card layout */}
              <div className="relative bg-slate-900/90 border border-slate-800 p-8 rounded-2xl shadow-2xl flex flex-col space-y-6">
                
                {/* Visual Header / Avatar frame */}
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="h-16 w-16 bg-pink-600 rounded-2xl flex items-center justify-center shadow-lg shadow-pink-500/20">
                      <LucideIcon name="Brain" className="text-white" size={32} />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-display font-extrabold text-lg text-white">Double-Tier Advantage</h3>
                    <p className="text-xs font-mono text-slate-400">Finance & Engineering Combined</p>
                  </div>
                </div>

                {/* Advantage bullet list */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3.5">
                  <div className="flex items-start text-xs sm:text-sm text-slate-300">
                    <div className="text-pink-500 mr-2.5 mt-0.5">
                      <LucideIcon name="Check" size={14} />
                    </div>
                    <span>
                      <strong className="text-white">Bullet-proof Audits:</strong> Custom macro models built with robust accounting double-entry verification.
                    </span>
                  </div>
                  <div className="flex items-start text-xs sm:text-sm text-slate-300">
                    <div className="text-pink-500 mr-2.5 mt-0.5">
                      <LucideIcon name="Check" size={14} />
                    </div>
                    <span>
                      <strong className="text-white">No External IT Dependencies:</strong> Rapid agile scripting deployed directly inside accounting files.
                    </span>
                  </div>
                  <div className="flex items-start text-xs sm:text-sm text-slate-300">
                    <div className="text-pink-500 mr-2.5 mt-0.5">
                      <LucideIcon name="Check" size={14} />
                    </div>
                    <span>
                      <strong className="text-white">AI-Grade Matching:</strong> Eliminating discrepancy noise using secure machine learning APIs.
                    </span>
                  </div>
                </div>

                {/* Simple Badge display */}
                <div className="border-t border-slate-800 pt-5 flex justify-between items-center text-xs text-slate-400">
                  <span className="font-mono">Process Compliance</span>
                  <span className="font-mono text-pink-500 font-bold uppercase tracking-tight bg-pink-500/10 px-2 py-0.5 rounded">
                    100% Secure
                  </span>
                </div>

              </div>

            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
