import { motion } from "motion/react";
import Header from "./components/Header";
import ServicesSection from "./components/ServicesSection";
import ExperienceSection from "./components/ExperienceSection";
import ContactSection from "./components/ContactSection";
import Chatbot from "./components/Chatbot";
import LucideIcon from "./components/LucideIcon";
import Starfield from "./components/Starfield";
import RkLogo from "./components/RkLogo";

export default function App() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 selection:bg-pink-600 selection:text-white">
      {/* Dynamic Animated Moving Starfield Background */}
      <Starfield />

      {/* Background Glimmer Glow Blobs */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-pink-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[800px] left-1/4 w-[600px] h-[600px] bg-slate-800/20 rounded-full blur-[150px] pointer-events-none" />

      {/* Global Header */}
      <Header />

      {/* Main Container */}
      <main className="pt-16">
        
        {/* HERO SECTION */}
        <section id="about" className="relative py-20 md:py-28 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Hero Copy */}
              <div className="lg:col-span-7 space-y-6 text-left">
                {/* Intro badge */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <span className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-pink-400 font-mono font-bold uppercase tracking-wider">
                    <span className="h-1.5 w-1.5 rounded-full bg-pink-500 animate-pulse" />
                    <span>Now Open for Corporate Automation Mandates</span>
                  </span>
                </motion.div>

                {/* Main Heading */}
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                  className="text-4xl sm:text-5xl lg:text-6xl font-display font-black text-white tracking-tight leading-tight"
                >
                  Bridging <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-pink-400 to-rose-400">Elite Finance</span> with High-Yield Automation
                </motion.h1>

                {/* Subtitle */}
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="text-lg sm:text-xl text-slate-400 leading-relaxed max-w-2xl"
                >
                  Optimize month-end close schedules, automate heavy multi-bank reconciliations, and drive efficiency with custom VBA macro modules, RPA engines, and direct AI implementations.
                </motion.p>

                {/* Quick Value Pillars */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2"
                >
                  <div className="flex items-center space-x-3 text-sm text-slate-300 font-medium">
                    <div className="flex-shrink-0 text-pink-500 bg-pink-500/10 p-1.5 rounded-lg">
                      <LucideIcon name="Briefcase" size={16} />
                    </div>
                    <span>18+ Years Corporate Accounting Experience</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-slate-300 font-medium">
                    <div className="flex-shrink-0 text-pink-500 bg-pink-500/10 p-1.5 rounded-lg">
                      <LucideIcon name="Cpu" size={16} />
                    </div>
                    <span>10+ Years Dedicated Software Automation</span>
                  </div>
                </motion.div>

                {/* Action Buttons */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                  className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-4 pt-4"
                >
                  <button
                    onClick={() => scrollToSection("services")}
                    className="px-6 py-3.5 rounded-xl bg-pink-600 hover:bg-pink-500 font-semibold text-white transition-all shadow-lg hover:shadow-pink-500/20 text-center cursor-pointer flex items-center justify-center space-x-2"
                  >
                    <span>Analyze Services</span>
                    <LucideIcon name="ArrowRight" size={16} />
                  </button>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-200 font-semibold transition-all text-center cursor-pointer"
                  >
                    Discuss RPA or VBA Needs
                  </button>
                </motion.div>
              </div>

              {/* Right Side Visual Gasket Card */}
              <div className="lg:col-span-5 relative">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="relative mx-auto max-w-sm rounded-3xl bg-slate-900 border border-slate-800/80 p-6 sm:p-8 shadow-2xl shadow-slate-950"
                >
                  {/* Decorative glowing gradient border */}
                  <div className="absolute -inset-[1px] bg-gradient-to-b from-pink-500/30 to-transparent rounded-3xl -z-10 blur-sm" />

                  {/* RK Profile Card */}
                  <div className="text-center space-y-4">
                    <div className="inline-block relative">
                      <div className="mx-auto flex justify-center">
                        <RkLogo size={80} showText={false} />
                      </div>
                      <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                        <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping absolute" />
                        <span className="h-2 w-2 rounded-full bg-emerald-500" />
                      </div>
                    </div>

                    <div>
                      <h2 className="text-2xl font-display font-extrabold text-white tracking-tight">Ram Halder</h2>
                      <span className="text-xs font-mono text-pink-400 font-bold uppercase tracking-widest block mt-1">
                        Finance & Automation Expert
                      </span>
                    </div>

                    <div className="border-t border-b border-slate-800/60 py-4 my-2 text-left space-y-2.5">
                      <div className="flex items-center space-x-3 text-xs text-slate-300">
                        <span className="text-pink-500 font-mono font-bold w-12 text-right">EMAILS</span>
                        <a href="mailto:rk.10.halder@gmail.com" className="hover:text-pink-400 transition-colors truncate font-mono">
                          rk.10.halder@gmail.com
                        </a>
                      </div>
                      <div className="flex items-center space-x-3 text-xs text-slate-300">
                        <span className="text-pink-500 font-mono font-bold w-12 text-right">MOBILE</span>
                        <a href="tel:+919818714744" className="hover:text-pink-400 transition-colors font-mono">
                          +91 9818714744
                        </a>
                      </div>
                      <div className="flex items-center space-x-3 text-xs text-slate-300">
                        <span className="text-pink-500 font-mono font-bold w-12 text-right">LOCATIONS</span>
                        <span className="font-mono text-slate-400">Delhi NCR, India (Global Remote Support)</span>
                      </div>
                    </div>

                    {/* Quick values card quote */}
                    <div className="p-4 bg-slate-950/40 rounded-2xl border border-slate-805/40 text-left">
                      <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block tracking-wider">Mindset Statement</span>
                      <p className="text-xs text-slate-300 leading-relaxed mt-1.5 italic">
                        &ldquo;I believe the best developers in finance are those who have spent decades doing manual books themselves. We know where the errors hide and we write code to kill them.&rdquo;
                      </p>
                    </div>

                  </div>
                </motion.div>
              </div>

            </div>
          </div>
        </section>

        {/* CORE SERVICES SECTION */}
        <ServicesSection />

        {/* EXPERIENCE TIMELINE SECTION */}
        <ExperienceSection />

        {/* CONTACT ME SECTION */}
        <ContactSection />

      </main>

      {/* FOOTER */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12 text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between text-center md:text-left gap-6">
          <div className="flex items-center">
            <RkLogo size={32} showText={true} />
            <div className="hidden sm:block border-l border-slate-800 ml-4 pl-4 py-1">
              <p className="text-xs text-slate-600 font-mono">Dual Expertise in Accounts & Desktop Automation</p>
            </div>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <a href="mailto:rk.10.halder@gmail.com" className="hover:text-pink-500 transition-colors">rk.10.halder@gmail.com</a>
            <a href="tel:+919818714744" className="hover:text-pink-500 transition-colors">+91 9818714744</a>
            <span className="text-xs font-mono text-slate-700">© 2026. Delhi NCR, India</span>
          </div>
        </div>
      </footer>

      {/* CHATBOT AI ASSISTANT Component */}
      <Chatbot />
    </div>
  );
}
